# Using this Demo

## Virtual Environment
- Create the virtual environment (python -m venv venv)
- Activate the venv
- Install modules
    - Make sure you have MySQL installed on your computer
    - pip install -r requriements.txt
    - pip freeze (to verify)

