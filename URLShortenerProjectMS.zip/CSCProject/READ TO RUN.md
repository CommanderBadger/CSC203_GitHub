### One-time setup (first time only)
1. Unzip this folder anywhere
2. Open a terminal or Command Prompt  in this folder
3. Run this single command:
   docker-compose up --build
4. Got to http://localhost:8080
5. Create account or use test account (username: test password: test)
6. Voila! You can now shorten URLs