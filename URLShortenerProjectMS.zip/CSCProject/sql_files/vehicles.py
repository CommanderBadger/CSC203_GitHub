

class urlSQL():

    def stored_URLs(self, id):

        sql = f'''
            select 
                s.*
                , u.users_UserID
            from 
                shortenedurls v 
                inner join user u on (s.UserID = u.UserID) 
            where 
                u.UserID = {id}'''

        return sql
    
    def user_details(self, username, password):

        sql = f'''
            select 
                u.UserID
                
            from 
                users
            where 
                u.Username = {username} AND u.Password = {password}'''
        return sql